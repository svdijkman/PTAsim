library(rhandsontable)

shinyUI(fluidPage(
		tags$head(tags$link(rel="icon", type="image/x-icon", href="favicon.ico"), tags$title("PTASim")),

		column(3, wellPanel(
				rHandsontableOutput("dft"),br(),
				radioButtons("TMIClvl","T>MIC",
					c("40%"="0.4",
					"50%"="0.5",
					"60%"="0.6"),inline=T
				),
				sliderInput("nsbj", 
					"Number of patients:", 
					value = 100,
					min = 1, 
					max = 1000
				),
				sliderInput("CLchg", 
					"Difference in CL:", 
					value = 0,
					min = -50, 
					max = 50
				),
				actionButton("goButton", "Evaluate!")
		)),
		column(5, wellPanel(
			tabsetPanel(
				tabPanel("PTA", plotOutput("PTAPlot"))
			)
		))
))


