#clean up all variables
rm(list=ls(all=TRUE))

library(data.table)
library(rhandsontable)
library(lattice)
library(latticeExtra)

#Set seed to ensure reproducability
set.seed(48910403)

#dfa<-as.data.frame(rbind(
#		c(500,"BID"),
#		c(875,"BID"),
#		c(1000,"BID"),
#		c(2000,"BID"),
#		c(500,"TID"),
#		c(875,"TID"),
#		c(1000,"TID")),stringsAsFactors = FALSE)

dfa<-as.data.frame(rbind(
		c(500,"BID")),stringsAsFactors = FALSE)

colnames(dfa)<-c("Dose","Interval")

#Pneu_distr<-function(shift=1,fit=list(mu=c(0.01,0.03),sigma=c(0.2,0.7),p=c(0.5,0.5))){
#	smp<-sample((1:length(fit$mu)),prob=fit$p,size=1)
#	res<-sapply(shift,function(x) exp(rnorm(1,log(fit$mu[smp]),fit$sigma[smp]))*x)
#	return(res)
#}

Pneu_distr<-function(shift=1,fit=list(mu=c(0.01,0.7),sigma=c(0.8,1.3),p=c(0.5,0.5))){
	smp<-sample((1:length(fit$mu)),prob=fit$p,size=1)
	res<-sapply(shift,function(x) exp(rnorm(1,log(fit$mu[smp]),fit$sigma[smp]))*x)
	return(res)
}

cr_dat<-function(regimen,nsbj=1000,nDay=1,CLchg=1){

	if(nsbj%%2>0) nsbj<-nsbj+1

	if(as.character(regimen$II)=="BID"){
		nDose<-2*nDay
		DoseT<-seq(0,(24*nDay)-12,by=12)
		TAU<-12
	} else if(as.character(regimen$II)=="TID"){
		nDose<-3*nDay
		DoseT<-seq(0,(24*nDay)-8,by=8)
		TAU<-8
	} else {
		nDose<-4*nDay
		DoseT<-seq(0,(24*nDay)-6,by=6)
		TAU<-6
	}

	DOSE<-as.numeric(as.character(regimen$DOSE))
	SCEN<-as.numeric(as.character(regimen$SCEN))

	tim<-seq(0,24*nDay,by=0.5)	#PK timepoints to be simulated
	ltim<-length(tim) #number of simulated timepoints

	#sample demographics
	SEX<-sample(c(0,1),nsbj,replace=T) #in case of random 50:50
	nMale<-sum(SEX)
	nFemale<-nsbj-nMale
	WT<-rep(0,nsbj)
	WT[SEX==0]<-rnorm(nFemale,65,12)
	WT[SEX==1]<-rnorm(nMale,75,15)

	#PK parameters for Augmentin
	TH1<-5
	TH2<-11
	TH3<-3.44
	TH4<-21.7
	TH5<-1.45
	TH6<-0.808
	TH7<-0.264
	TH8<-0.673

	OM1<-0.0164
	OM2<-0.0128
	OM3<-0.409
	OM4<-0.0568
	OM5<-0.034

	SI1<-0.114
	SI2<-0.00592

	#Sample parameter values
	CL<-(TH1+TH2*(WT/70)*exp(rnorm(nsbj,0,sqrt(OM1))))*CLchg
	V<-TH3+TH4*(WT/70)*exp(rnorm(nsbj,0,sqrt(OM2)))
	KA<-((TH5+TH6)/2)*exp(rnorm(nsbj,0,sqrt(OM3)))	#average taken between non-fat and high-fat fed
	ALAG1<-TH7*exp(rnorm(nsbj,0,sqrt(OM4)))
	F1<-TH8*exp(rnorm(nsbj,0,sqrt(OM5)))

	dat<-data.frame(ID=rep(1:nsbj,each=ltim))
	dat$TIME<-rep(tim,nsbj)
	dat$AMT<-0
	dat$DOSE<-DOSE
	dat$EVID<-0
	dat$MDV<-0
	dat$DV<-0
	dat$WT<-rep(WT,each=ltim)
	dat$CMT<-2
	dat$CL<-rep(CL,each=ltim)
	dat$V<-rep(V,each=ltim)
	dat$KA<-rep(KA,each=ltim)
	dat$ALAG1<-rep(ALAG1,each=ltim)
	dat$F1<-rep(F1,each=ltim)
	dat$TAU<-TAU

	dos<-data.frame(ID=rep(1:nsbj,each=nDose))
	dos$TIME<-DoseT
	dos$AMT<-DOSE
	dos$DOSE<-DOSE
	dos$EVID<-1
	dos$MDV<-1
	dos$DV<-0
	dos$WT<-rep(WT,each=nDose)
	dos$CMT<-1
	dos$CL<-rep(CL,each=nDose)
	dos$V<-rep(V,each=nDose)
	dos$KA<-rep(KA,each=nDose)
	dos$ALAG1<-rep(ALAG1,each=nDose)
	dos$F1<-rep(F1,each=nDose)
	dos$TIME<-dos$TIME+dos$ALAG1 #simple hack to account for absorption lag time, is revoked at end of simulation
	dos$TAU<-TAU

	out<-rbind(dos,dat)
	out<-out[order(out$ID,out$TIME,1-out$EVID,out$CMT),]

	out$KE<-out$CL/out$V
	out$A1<-0
	out$A1[out$MDV==1]<-out$AMT[out$MDV==1]*out$F1[out$MDV==1]
	out$A2<-0
	out<-as.data.table(out)
	out$TIM1<-out$TIME%%TAU

	out<-out[,{
		IPRED=(DOSE*F1/V)*(KA/(KA-KE))*((exp(-KE*TIM1)/(1-exp(-KE*TAU)))-(exp(-KA*TIM1)/(1-exp(-KA*TAU))));
		list(ID=ID,TIME=TIME,IPRED=IPRED,EVID=EVID,ALAG1=ALAG1,CMT=CMT)
		},by=ID]

	#xyplot(IPRED~TIME,data=out[ID==1,])

	out$TIME[out$EVID==1]<-out$TIME[out$EVID==1]-out$ALAG1[out$EVID==1]
	out<-out[order(out$ID,out$TIME,1-out$EVID,out$CMT),]
	out$SCEN<-SCEN
	out$ID<-out$ID+(SCEN-1)*nsbj
	out<-out[out$EVID==0,]

	return(out)
}

eval_PTA<-function(TMIClvl=0.4,multi=1,year="2020"){

	res<-d[,{	SCEN = unique(SCEN);
			YEAR = year;
			MIC  = Pneu_distr()*multi;
			TMIC = sapply(MIC,function(MICi){length(TIME[IPRED>MICi])/length(TIME)});
			list(SCEN=SCEN,MIC=MIC,YEAR=YEAR,TMIC=TMIC)}
			,by=ID]
	res$TA<-res$TMIC>=TMIClvl

	tmp<-res[,.(
			TMIC = TMIClvl,
			PTA  = sum(as.numeric(TA))/length(TA))
			,by="SCEN,YEAR"]

	return(tmp)
}

shinyServer(function(input, output, session){

	simregt <- reactive({
		input$goButton
		isolate({
			dft <- input$dft
			if (!is.null(dft)) hot_to_r(dft)
		})#isolate
	})

	output$dft = renderRHandsontable({
		rhandsontable(dfa)
  	})

	dataset <- eventReactive(input$goButton,{


		#isolate({
			simreg<-simregt()
			if(!exists("simregold")) simregold<-data.frame(NAME="")
			if(!exists("nsbjold")) nsbjold<-""

			nsbj<-input$nsbj
			CLchg<-1+input$CLchg/100
			
			if(!is.null(simreg)){
				colnames(simreg)<-c("DOSE","II")
				simreg$SCEN<-(1:nrow(simreg))
				simreg$NAME<-paste0(simreg[,1],"mg ",simreg[,2])
				simreg<<-simreg[,c("SCEN","DOSE","II","NAME")]

				if(any(!simreg$NAME%in%simregold$NAME) | is.character(all.equal(nsbj,nsbjold))){

					simregold<<-simreg
					nsbjold<<-nsbj
					d<<-rbindlist(lapply(split(simreg,(1:dim(simreg)[1])),cr_dat,nsbj=nsbj,nDay=1,CLchg=CLchg))
					d<<-d[,c("ID","TIME","IPRED","SCEN")]
					d
				}
			}
		#})#isolate
	})#data

	output$PTAPlot <- renderPlot({

		input$goButton

		isolate({
			d<-dataset()

			MIClvls<<-c(0.015,0.03,0.06,0.125,0.25,0.5,1,2,4,8,16)
			TMIClvl<-as.numeric(input$TMIClvl)

			summF<-eval_PTA(multi=c(1,1.25,1.5,2,3),
				year=c("2020","2025","2030","2035","2040"))
			summF$NAME<-simreg$NAME[summF$SCEN]

			setDF(summF)

			lbl<-c("0%","+25%","+50%","+100%"," +200%")

			cBACT<-"S. pneumoniae"
			PTAref<-c(90)
			PTAcol<-c("red")

			nSCEN<-length(unique(summF$SCEN))
			if(nSCEN%/%3==0){ xn<-nSCEN;yn<-1 }
			if(nSCEN%/%3==1){ xn<-3;yn<-2 }
			if(nSCEN%/%3>1){ xn<-3;yn<-3 }

			xyplot(PTA*100~YEAR|factor(NAME,levels=unique(summF$NAME)),as.table=T,layout=c(xn,yn),
				main=paste0("PTA for T>MIC >",TMIClvl*100,"%\n","for bacterium ",cBACT),
				xlim=c(2017.5,2042.5),ylim=c(0,105),data=summF,
				scales=list(tck=c(1,0),alternating=c(1,1),x=list(cex=0.7,at=unique(summF$YEAR),label=lbl)),
				type="b",abline=list(h=PTAref,col=PTAcol,lwd=2),
				xlab="Change in Minimum Inhibitory Concentration (%)",ylab="Probability of Target Attainment (%)",
				key=list(text=list(c(paste0("PTA = ",PTAref,"%"))),lines=list(col=c(PTAcol),lwd=2),columns=1,corner=c(1,0)))
		})#isolate
	})#renderPlot

})#shinyServer


